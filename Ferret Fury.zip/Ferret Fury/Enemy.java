/*Enemy.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The progrma contains functions for enemy objects
 */

class Enemy extends InanimateObject{
  private int damage; 
  private boolean colliding;
  /**
   * Enemy
   * This construtor creates a enemy object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param int damage stores amount of damage object can cause
   */
  Enemy (int x, int y, int damage){ 
    super (x, y); 
    this.damage = damage; 
  }//**end constructor 
  
 /**
   * Enemy
   * This construtor creates a enemy object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   */
  Enemy (int x, int y){
    super (x,y);
  }
  
  /**
   * getDamage
   * This method returns the damage the object has
   * @return int damage, the amount of damage the enemy can cause
   */
  public int getDamage (){ 
    return damage; 
  }//**end get method 
  
  /**
   * getColliding
   * This method returns whether or not character has collided
   * @return boolean colliding, the value of whether it's colliding or not
   */
  public boolean getColliding(){
    return colliding;
  }
  
   /**
   * setColliding
   * This method sets whether or not character has collided
   * @param boolean value, the new value of whether it's colliding or not
   */
  public void setColliding(boolean value){
    this.colliding=value;
  }
  
}//**end class enemy 


