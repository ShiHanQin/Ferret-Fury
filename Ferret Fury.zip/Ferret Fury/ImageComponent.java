/*ImageComponent.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program reads images in that will be used
 */

import java.awt.EventQueue;
import java.awt.Graphics;
import java.awt.Image;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JComponent;
import javax.swing.JFrame;

class ImageComponent extends JComponent{
  //Variables used to make images  
  private Image ferret, enemies, background, titleScreen, instructionsScreen, aboutScreen;
  
  /**
   * ImageComponent
   * This constructor creates new images
   */
  public ImageComponent(){
    try{
      //Ferret character
      File image2 = new File("ferret.png");
      ferret = ImageIO.read(image2);
      ferret= ferret.getScaledInstance(40, 40, Image.SCALE_DEFAULT);
      //Eagle png are enemies
      File image3 = new File("enemies.png");
      enemies = ImageIO.read(image3);
      enemies= enemies.getScaledInstance(55, 50, Image.SCALE_DEFAULT);
      //Background image
      File image4 = new File("grassland2.jpg");
      background = ImageIO.read(image4);
      background= background.getScaledInstance(2000, 1050, Image.SCALE_DEFAULT);
      //Title picture/header
      File image5 = new File("Title.png"); 
      titleScreen = ImageIO.read(image5); 
      titleScreen = titleScreen.getScaledInstance(300, 300, Image.SCALE_DEFAULT); 
      //Instruction panel header
      File image6 = new File("Instructions Panel.png");
      instructionsScreen = ImageIO.read(image6); 
      instructionsScreen = instructionsScreen.getScaledInstance(600, 600, Image.SCALE_DEFAULT); 
      //About panel header
      File image7 = new File("About Panel.png");
      aboutScreen = ImageIO.read(image7); 
      aboutScreen = aboutScreen.getScaledInstance(600, 600, Image.SCALE_DEFAULT);
    }
    catch (IOException e){
      e.printStackTrace();
    }
  }
  
  /**
   * getFerret
   * This method returns the image
   * @return Image ferret, is used to draw the image
   */
  public Image getFerret(){
    return ferret;
  }
  
  /**
   * getEnemies
   * This method returns the image
   * @return Image enemies, is used to draw the image
   */
  public Image getEnemies(){
    return enemies;
  }
  
  /**
   * getGrassland
   * This method returns the image
   * @return Image background, is used to draw the image
   */
  public Image getGrassland(){
    return background;
  }
  
  /**
   * getTitleScreen
   * This method returns the title panel
   * @return Image titleScreen, is used to draw the image
   */
    public Image getTitleScreen(){ 
      return titleScreen;
    }
    
    /**
     * getInstructions
     * This method returns the instruction panel
     * @return Image instructionScreen, is used to draw the image
     */
    public Image getInstrutionsScreen(){
      return instructionsScreen; 
    }
    
    /**
     * getAboutScreen
     * This method returns the about panel
     * @return Image aboutScreen, is used to draw the image
     */
    public Image getAboutScreen(){
      return aboutScreen;
    }
}//end of class