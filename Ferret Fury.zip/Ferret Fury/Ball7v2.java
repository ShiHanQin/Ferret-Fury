/*Ballv2.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains most fo the logic, graphics, and objects game has
 */

//Imports:
import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;
import java.awt.Image; 
import java.awt.image.BufferedImage;


public class Ball7v2 extends JFrame implements ActionListener, KeyListener {
  
  //Images to be used in program:
  ImageComponent ferret= new ImageComponent(); 
  ImageComponent enemies= new ImageComponent();
  ImageComponent background= new ImageComponent(); 
  
  //Variable declaration
  Timer t = new Timer(5, this);
  Ferret character = new Ferret (0,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.85)), 0,0,20); //Create a moving ferret character with constructor
  public boolean jumping=false; //Boolean used for determining whether or not object should be jumping
  public long jumpingTime=1000; //Amount of time used to jump upward
  int delta=1; //This is variable in control of which direction the enemies will move, and will allow those objects to move between a set boundary
  public int level;//Integer used to keep track of the level the game is on  
  
  //Object Initialization:
  //Key is the object character must collect each level to advance
  Keys []levelKey = new Keys[] {
    new Keys(1880, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.05)-30), false),
      new Keys(1880, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.05)-30), false),
      new Keys(1880, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.05)-30), false),
  };
  
  //Declare the genreal array of each type of object, will be set to other arrays as game levels up
  PlatformsX[] platform = new PlatformsX[25];
  Collectables[] levelCollectables = new Collectables[10];
  Enemy[] levelEnemies = new Enemy[6];
  Enemy[] orgLvlEnemies = new Enemy[6];
  
  ///////////////////////////////////////////////LEVEL ONE OBJECTS//////////////////////////////////////////////////////////////////////
  PlatformsX[] platform1=new PlatformsX[]{ //Several platforms are created
    new PlatformsX(100,0.8,20,90),        //We decided to not randomly generate the platform positions, 
      new PlatformsX(350,0.8,20,150),       //so that is why this is such a large block of initialization
      new PlatformsX(900,0.8,20,300),
      new PlatformsX(1700,0.8,20,80),
      new PlatformsX(175,0.65,20,220),
      new PlatformsX(600,0.65,20,400),
      new PlatformsX(1200,0.65,20,300),
      new PlatformsX(1600,0.65,20,100),
      new PlatformsX(40,0.5,20,200),
      new PlatformsX(400,0.5,20,100),
      new PlatformsX(900,0.5,20,300),
      new PlatformsX(1500,0.5,20,300),
      new PlatformsX(100,0.35,20,90),
      new PlatformsX(350,0.35,20,1000),
      new PlatformsX(1425,0.35,20,350),
      new PlatformsX(200,0.20,20,400),
      new PlatformsX(900,0.20,20,300),
      new PlatformsX(1700,0.20,20,200),
      new PlatformsX(10,0.05,20,450),
      new PlatformsX(350,0.05,20,150),
      new PlatformsX(1200,0.05,20,700)
  };
  Collectables[] level1Collectables= new Collectables[]{ //These are objects the player can collect to increase health
    new Collectables (110, 840),
      new Collectables (1720, 840),
      new Collectables (900, 680),
      new Collectables (200, 515),
      new Collectables (1550, 515),
      new Collectables (1000, 350),
      new Collectables (1800, 190),  
      new Collectables (50, 30) 
  };
  
  Enemy[] level1Enemies= new Enemy[]{ //These are objects the player must avoid, else they will lose health
    new Enemy (400, 820, 2),
      new Enemy (775, 660, 2),
      new Enemy (100, 495, 2),
      new Enemy (1600, 495, 2),
      new Enemy (800, 330, 2),
      new Enemy (200, 10, 2)
  };
  Enemy[] orgLvl1Enemies= new Enemy[]{ //Duplicate array of enemies with original position is created
    new Enemy (400, 820),              //This is used to keep track of where enemy is able to move
      new Enemy (775, 660),
      new Enemy (100, 495),
      new Enemy (1600, 495),
      new Enemy (800, 330),
      new Enemy (200, 10)
  };
  
  /////////////////////////////////////////////////LEVEL TWO OBJECTS///////////////////////////////////////////////////////////////
  PlatformsX[] platform2=new PlatformsX[]{
    new PlatformsX(0,0.8,20,480),//1
      new PlatformsX(950,0.8,20,500),//2
      new PlatformsX(130,0.7,20,490),//3
      new PlatformsX(1300,0.7,20,300),//4
      new PlatformsX(800,0.6,20,890),//5
      new PlatformsX(470,0.5,20,470),//6
      new PlatformsX(1580,0.4,20,700),//7 
      new PlatformsX(1000,0.3,20,720),//8
      new PlatformsX(220,0.3,20,550),//9
      new PlatformsX(920,0.15,20,350),//10
      new PlatformsX(0,0.05,20,350),//11
      new PlatformsX(1500,0.05,20,700)//12
  };
  Collectables[] level2Collectables= new Collectables[]{
    new Collectables (10,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.80)-30)),//1
      new Collectables (1500,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.70)-30)),//3
      new Collectables (475,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.50)-30)),//4
      new Collectables (1240,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.3)-30)),//8
      new Collectables (260, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.05)-30)),//9
  };
  
  Enemy[] level2Enemies= new Enemy[]{ //These are objects the player must avoid, else they will lose health
    new Enemy (500, 920, 3),
      new Enemy (1200, 200, 3),
      new Enemy (200, 250, 3),
      new Enemy (1500, 450, 3),
      new Enemy (550, 500, 3),
      new Enemy (1750, 900, 3)
  };
  Enemy[] orgLvl2Enemies= new Enemy[]{ //Duplicate array of enemies with original position is created
    new Enemy (500, 920),              //This is used to keep track of where enemy is able to move
      new Enemy (1200, 200),
      new Enemy (200, 250),
      new Enemy (1500, 450),
      new Enemy (550, 500),
      new Enemy (1750, 900)
  };
  
/////////////////////////////////////////////////////LEVEL THREE OBJECTS///////////////////////////////////////////////////
  PlatformsX[] platform3=new PlatformsX[]{
    new PlatformsX(240,0.8,20,480),//1
      new PlatformsX(1500,0.8,20,680),//1.5
      new PlatformsX(960,0.7,20,240),//2
      new PlatformsX(1440,0.6,20,245),//3
      new PlatformsX(0,0.6,20,240),//4
      new PlatformsX(480,0.6,20,240),//5
      new PlatformsX(900,0.5,20,500),//6
      new PlatformsX(1450,0.4,20,2000),//7 
      new PlatformsX(280,0.4,20,440),//8
      new PlatformsX(0,0.3,20,260),//9
      new PlatformsX(600,0.3,20,500),//10
      new PlatformsX(1250,0.15,20,100),//11
      new PlatformsX(490,0.15,20,150),//12
      new PlatformsX(0,0.05,20,500),//12.5
      new PlatformsX(1500,0.05,20,700)//13
  };
  Collectables[] level3Collectables= new Collectables[]{
    new Collectables (1850,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.9)-30)),//1
      new Collectables (1000,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.65)-30)),//2
      new Collectables (1650,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.6)-30)),//3
      new Collectables (450,((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.4)-30)),//8
      new Collectables (1860, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.35)-30)),//7
      new Collectables (10, ((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.05)-30)),//13.5
  };
  
  Enemy[] level3Enemies= new Enemy[]{ //These are objects the player must avoid, else they will lose health
    new Enemy (200, 520, 5),
      new Enemy (400, 200, 5),
      new Enemy (700, 800, 5),
      new Enemy (100, 15, 5),
      new Enemy (600, 50, 5),
      new Enemy (1650, 700,5)
  };
  Enemy[] orgLvl3Enemies= new Enemy[]{ //Duplicate array of enemies with original position is created
    new Enemy (200, 520),              //This is used to keep track of where enemy is able to move
      new Enemy (400, 200),
      new Enemy (700, 800),
      new Enemy (100, 15),
      new Enemy (600, 50),
      new Enemy (1650, 700)
  };
//************************************************END OF OBJECT DECLARATION*****************************************   
//**************************************START OF COLLISION DETECTION AND MOVEMENT CODE****************************** 
  /**
   * Ball7v2
   * This constructor creates the game screen
   */
  public Ball7v2(int input) {
    super("Ferret Fury");
    level= input; 
    GamePanel gameScreen = new GamePanel(); 
    add(gameScreen); 
    t.start();//**start timer 
    addKeyListener(this);
    setFocusable(true);
    setFocusTraversalKeysEnabled(false);
    setSize(Toolkit.getDefaultToolkit().getScreenSize());
    setVisible(true);  
  }
  
  private class GamePanel extends JPanel{
    
    /**
     * paintComponent
     * This method draws everything
     * @param Graphics object, used to draw 
     */
    public void paintComponent(Graphics g) {
      super.paintComponent(g);
      g.drawImage(background.getGrassland(), 0, 0, this); //Draw the background
      
      //Draw the health bar
      g.setColor(Color.WHITE);
      g.fillRect((int)(Toolkit.getDefaultToolkit().getScreenSize().width*0.95)-character.getHealth()*20-5,(int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.90-5),character.getHealth()*20+5,30);
      g.setColor(Color.RED);
      g.fillRect((int)(Toolkit.getDefaultToolkit().getScreenSize().width*0.95)-character.getHealth()*20,(int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.90),character.getHealth()*20,25);
      
      int r = level-1; //for keeping track of levelKey array
      //simply name "r" because it's just a counter
      
      //Set everything to level 1
      if (level ==1){
        platform = platform1; 
        levelCollectables = level1Collectables; 
        levelEnemies = level1Enemies; 
        orgLvlEnemies = orgLvl1Enemies;
      }
      //Set everything to level 2
      else if (level ==2){
        platform = platform2; 
        levelCollectables = level2Collectables; 
        levelEnemies = level2Enemies; 
        orgLvlEnemies = orgLvl2Enemies;
      }
      //Set everything to level 3
      else if (level ==3){
        platform = platform3; 
        levelCollectables = level3Collectables; 
        levelEnemies = level3Enemies; 
        orgLvlEnemies = orgLvl3Enemies;
      }
      
      //COLLISION DETECTION/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
      
      //Check collision with collectables
      for (int i=0;i<levelCollectables.length;i++){
        if ((character.getX()>levelCollectables[i].getX()-30)&& (character.getX()<levelCollectables[i].getX()+20)
              &&(character.getY()<levelCollectables[i].getY()+20)&&(character.getY()>levelCollectables[i].getY()-40)){//**checks for center of the object 
          //character.setNumCollectables(character.getNumCollectables()+1);
          //Set coordinates of collectable off the page so it "disappears" once collected
          levelCollectables[i].setX(-1000);
          levelCollectables[i].setY(-1000);
          character.setHealth(character.getHealth()+1);
        } 
      }
   
      //Check collision with enemies
      for (int i=0;i<levelEnemies.length;i++){
        if ((character.getX()>levelEnemies[i].getX()-30)&& (character.getX()<levelEnemies[i].getX()+40)
              &&(character.getY()<levelEnemies[i].getY()+20)&&(character.getY()>levelEnemies[i].getY()-30)){
          if (!levelEnemies[i].getColliding()) {
            character.setHealth(character.getHealth()-levelEnemies[i].getDamage());  //A little buffer is set before the enemy can collide again and again 
          }
          levelEnemies[i].setColliding(true);
          
          if (character.getHealth()<=0){ //Make character die when health is too low
            character.setX(100000);//This will make it disappear off the screen
            character.setY(100000);
            try{ Thread.sleep(1000); }catch(Exception e) {};
            dispose(); //Get rid of current screen when character dies 
          }
        } else {
          levelEnemies[i].setColliding(false);//Make it possible to collide again
        }
      }
      
      boolean keyCollected = levelKey[r].getCollected(); //This variable is only created so we can use it in the if statement
      //Check collision with portal
      if ((character.getX()>levelKey[r].getX()-30)&& (character.getX()<levelKey[r].getX()+20)
            &&(character.getY()<levelKey[r].getY()+20)&&(character.getY()>levelKey[r].getY()-40)&& (level < 4) && (keyCollected= true)){
        
        try{ Thread.sleep(1000); }catch(Exception e) {};
        
        //Level up
        level++; 
        //keyOpen[r].setCollected(false); //Set to false so it can be collected next level 
        levelKey[r].setCollected(false); //Set to false so it can be collected next level 
        levelKey[r].setX(-1000);
        levelKey[r].setY(-1000);
        character.setX(0); //Set the position back to bottom left
        character.setY((int)(Toolkit.getDefaultToolkit().getScreenSize().height*0.9));
        revalidate();   
        if(level==4){
          try{ Thread.sleep(1000); }catch(Exception e) {};
          dispose(); //Get rid of current screen to move onto next
        }
      }
      
      ////////////////////////////////////////////////////DRAWING OBJECTS////////////////////////////////////////////////////////
      //Draw the character
      g.drawImage(ferret.getFerret(), character.getX(), character.getY(), this);
      
      //Draw the key (one key per level, needs to be collected for the player to advance
      g.setColor(Color.YELLOW);
      g.fillOval(levelKey[r].getX(), levelKey[r].getY(), 40,15);
      //Draw the platforms
      for (int i=0;i<platform.length;i++){
        g.setColor(Color.BLACK);
        g.fillRect(platform[i].getX(),platform[i].getY(),platform[i].getWidth(),platform[i].getHeight());
      }
      //Draw the collectables
      for (int i=0;i<levelCollectables.length;i++){
        g.setColor(Color.GREEN);
        g.fillOval(levelCollectables[i].getX(),levelCollectables[i].getY(),20,20);
      }
      //Draw the enemies
      for (int i=0;i<levelEnemies.length;i++){
        g.drawImage(enemies.getEnemies(), levelEnemies[i].getX(),levelEnemies[i].getY(), this);
        
        levelEnemies[i].setX(levelEnemies[i].getX()+delta);//Moves the enemies in right directions
        if (levelEnemies[i].getX()>orgLvlEnemies[i].getX()+70){
          delta*=-1; //Will change direction of movement
          levelEnemies[i].setX(orgLvlEnemies[i].getX()+70);
        }
        else if (levelEnemies[i].getX()<orgLvlEnemies[i].getX()){
          delta*=-1;  //Will change direction of movement
          levelEnemies[i].setX(orgLvlEnemies[i].getX());
        }//end else if 
      }//end for loop
      
      if(!jumping){ //falling 
        character.setY(character.getY()+1);
      }
      if(jumping){//**reaches max height, then sets jumping - false 
        character.setY(character.getY()-2);
      }
    }//paint component
  }//end private class
  
  /**
   * actionPerformed
   * This method responds to what is happening and allows program to run accordingly
   * @param ActionEvent e, used to change what's going on
   */
  public void actionPerformed(ActionEvent e) {
    PlatformsX[] platform = new PlatformsX[25];
    if (level ==1){
      platform = platform1; 
    }
    else if (level ==2){
      platform = platform2; 
    }
    else if (level ==3){
      platform = platform3; 
    } 
    
    //Set the position at edge of screen if reached
    if(character.getX() < 0){
      character.setVelX(0);
      character.setX(0);  
    }
    //Set the position at edge of screen if reached
    if(character.getX() > 2000){
      character.setVelX(0);
      character.setX(2000);  
    }
    //Set the position at edge of screen if reached
    if(character.getY() < 0){
      character.setVelY(0);
      character.setY(0);  
    }
    //Set the position at edge of screen if reached
    if(character.getY() > (0.95*(Toolkit.getDefaultToolkit().getScreenSize().height-30))){
      character.setVelY(0);
      character.setY((int)(0.95*(Toolkit.getDefaultToolkit().getScreenSize().height-30)));  
    }
    
    ////////////////////////////Check for platform contact ////////////////////////////////////////////////
    for (int i=0;i<platform.length;i++){
      //Check top of platform
      if ((character.getX()>platform[i].getX()-30) && (character.getX()<(platform[i].getX()+platform[i].getWidth()))&& (character.getY()<platform[i].getY())&&(character.getY()>platform[i].getY()-30)){//**detects top right corner of the object 
        character.setY(platform[i].getY()-30);
        character.setVelY(0);
      }
      //Check bottom of platform
      if ((character.getX()>platform[i].getX()-30) && (character.getX()<(platform[i].getX()+platform[i].getWidth()))&& (character.getY()<platform[i].getY()+platform[i].getHeight())&&(character.getY()>platform[i].getY())){//**detects top right corner of the object 
        jumping = false; 
      }  
      //Check left side of platform
      if ((character.getX()>platform[i].getX()-30) && (character.getX()<(platform[i].getX()))&& (character.getY()<platform[i].getY()+platform[i].getHeight())&&(character.getY()>platform[i].getY())){//**detects top right corner of the object 
        character.setY(platform[i].getY()+platform[i].getHeight());
        character.setVelY(0);
      } 
      //Check right side of platform
      if ((character.getX()>platform[i].getX()+platform[i].getWidth()) && (character.getX()<platform[i].getX()+platform[i].getWidth()/**/)&& (character.getY()<platform[i].getY()+platform[i].getHeight())&&(character.getY()>platform[i].getY())){//**detects top right corner of the object 
        character.setY(platform[i].getY()+platform[i].getHeight());
        character.setVelY(0);
      }//end of if
    }//end of platform for loop
    
    //Character position is changed according to other values
    character.setX(character.getX()+character.getVelX());
    character.setY(character.getY()+character.getVelY());//**change position while jumping 
    
    repaint();
  }//end of actionPerformed
  
  /**
   * keyPressed
   * This method changes the velocities and positions of the character to simulate movement
   * @param KeyEvent e, used to change what's going on
   */
  public void keyPressed(KeyEvent e) {
    int code = e.getKeyCode();
    
    //Fall if down is pressed
    if (code == KeyEvent.VK_DOWN){
      character.setVelY(2);
      character.setVelX(0);
    }
    //Jump if up is pressed
    if (code == KeyEvent.VK_UP){
      jumping=true;
      new Thread(new thread()).start();
    }
    //Go left if left is pressed
    if (code == KeyEvent.VK_LEFT){
      character.setVelY(0);
      character.setVelX(-2);
    }
    //Go right if right is pressed
    if (code == KeyEvent.VK_RIGHT){
      character.setVelY(0);
      character.setVelX(2); 
    }//end of if
  }//end of keyPressed
  
  /**
   * keyTyped
   * We did not use this in our method, but it is included as part of the interface
   * @param KeyEvent e
   */
  public void keyTyped(KeyEvent e) {}
  
  /**
   * keyReleased
   * Used to determine what to do when key is released
   * @param KeyEvent e
   */
  public void keyReleased(KeyEvent e) {
    //When nothing is pressed
    character.setVelX(0);
    character.setVelY(0);
    if (e.getKeyCode()==KeyEvent.VK_UP){
      character.setY(character.getY()+1);
    }//end of if
  }//end of keyReleased
  
  public class thread implements Runnable{
    
    /**
     * run
     * Used to make character jump according to set time
     */
    @Override
    public void run(){
      //This allows the character to jump
      try{
        Thread.sleep(jumpingTime);
        jumping=false;
      }catch (Exception e){
        e.printStackTrace();
        new Thread(this).start();
        System.exit(0);
      }//end of catch block
    }//end of run() method
  }//end of thread
}//end of class