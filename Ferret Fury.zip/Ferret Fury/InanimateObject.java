/*InanimateObject.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for inanimate objects like the platforms and collectables
 */

abstract class InanimateObject {
  private int xCord; 
  private int yCord; 
  
  /**
   * InanimateObject
   * This constructor creates an inanimate object with only the position
   * @param int x, x position of object
   * @param int y, y position of object
   */
  InanimateObject(int x, int y){
    xCord = x; 
    yCord = y;
  }//**end constructor 
  
  /**
   * getX
   * This method returns the x position of the object
   * @return int x, x position of object
   */
  public int getX(){
    return xCord; 
  }//**end method 
  
  /**
   * getY
   * This method returns the y position of the object
   * @return int y, y position of object
   */
  public int getY (){ 
    return yCord; 
  }//**end method 
  
  /**
   * setX
   * This method set the new x position of the object
   * @param int x, new x position of object
   */
  public void setX(int x){
    this.xCord=x;
  }
  
   /**
   * setY
   * This method set the new y position of the object
   * @param int y, new y position of object
   */
  public void setY(int y){
    this.yCord=y;
  }
}//**end class 
