/*Keys.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for key and portal objects
 */

class Keys extends InanimateObject {
  //private String openPath; 
  private boolean collected=false;
  
  /**
   * Keys
   * This construtor creates a key object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param boolean collected stores whether key has been collected or not
   */
  Keys (int x, int y, boolean collected){
    super (x, y); 
    this.collected=collected;
  }//**end constructor 
  
  /**
   * setCollected
   * This method updates whether or not key has been collected
   * @param boolean collected will be used to update if the key has been collected or not
   */
  public void setCollected(boolean collected){
    this.collected=collected;
  }
  
  /**
   * getCollected
   * This method returns whether or not key has been collected
   * @return boolean collected will be used to see if the key has been collected or not
   */
  public boolean getCollected(){
    return collected;
  }
}//**end subclass 


