/*PlatformsX.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for platform objects
 */

import java.awt.*;

class PlatformsX extends InanimateObject{
  private int posX, posY, height, width;
 
  /**
   * PlatformsX
   * This construtor creates a platform object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   */
  PlatformsX(int posX, int posY){
    super (posX, posY);
  }
  
  /**
   * PlatformsX
   * This construtor creates a platform object
   * @param int x stores the object's x position
   * @param double y stores percent used to calculate where on screen position y is
   * @param int height stores the height of the platform
   * @param int width stores the width of the platform
   */
  PlatformsX(int posX, double posY, int height, int width){
    super (posX,(int)(posY*Toolkit.getDefaultToolkit().getScreenSize().height));
    this.height=height;
    this.width=width;
  }

  /**
   * getHeight
   * This method returns height of the platform
   * @return int height, platform's height
   */
  public int getHeight(){
    return height;
  }
  
  /**
   * getWidth
   * This method returns width of the platform
   * @return int width, platform's width
   */
  public int getWidth(){
    return width;
  }
}
