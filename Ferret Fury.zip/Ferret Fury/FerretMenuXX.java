/*FerretMenuXX
 * 
 * the main menu screen of the game Ferret Fury 
 * January 18th, 2018
 * @author Joanna Tien 
 * 
 * */
import javax.swing.*; 
import java.awt.*;  
import java.awt.event.*; 
import java.io.*; 
import javax.imageio.ImageIO; 
public class FerretMenuXX extends JFrame implements ActionListener{

  //Buttons and panels
  JButton instructions = new JButton ("INSTRUCTIONS"); 
  JButton playButton = new JButton ("PLAY"); 
  JButton aboutButton = new JButton ("ABOUT"); 
  JButton exitButton = new JButton ("EXIT"); //**creates buttons for the user to press 
  JButton back2Menu = new JButton ("MENU"); //**button to go back to menu 
  JButton back2Menu2 = new JButton ("MENU");
  
  //Use box layout
  Box buttons = Box.createVerticalBox();
  Box titlePanel = Box.createVerticalBox();
  JPanel finalPanel = new JPanel (); 
  Box instructionsPanel = Box.createVerticalBox();
  Box overview = Box.createVerticalBox();
  JPanel gameScreen = new JPanel(); 
  JPanel congrats= new JPanel();//**creates 3 panels (2 panels & one box) 
                                     //**one for the title, one for the buttons 
                                     //**the last combined to put onto the box layout 
  
  //Get the dimensions
  Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
  int width = (int)(screenSize.getWidth());
  int height = (int)(screenSize.getHeight());//**Gets the size of the computer screen 
  
  /*Game Panel Components*/ 
  JButton nextLevel = new JButton ("NEXT LEVEL"); 
  JButton toMainMenu = new JButton ("MAIN MENU"); 
  JLabel levelComplete = new JLabel ("Level Complete!");

  //create image component to add to screen 
  ImageComponent titleScreen= new ImageComponent(); 
  ImageComponent instructionsScreen= new ImageComponent(); 
  ImageComponent aboutScreen = new ImageComponent(); 
  
//***************************************************************************************************************************
 
  /*Constructor for Ferret Menu JFrame
   * */ 
  public FerretMenuXX() { //**constructor 
    setTitle ("Ferret Fury"); 
    setSize (width, height); 
    setResizable(true);
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//**sets size to fit computer screen, and unable to resize 
    
    //sets background image of frame 
     try{
    setContentPane(new JLabel(new ImageIcon(ImageIO.read(new File("nbmwlan.jpg")))));//**change to a folder location
    setLayout(new FlowLayout());
    } catch (IOException e){
      System.out.println("Error in loading image");  
    }
    
    
    BoxLayout firstBox = new BoxLayout (finalPanel, BoxLayout.Y_AXIS); //**boxLayout 
    finalPanel.setLayout (firstBox); 
    titlePanel.add(Box.createVerticalStrut(50)); 
    
    //**add the image title of the game 
    ImageIcon leafBk =new ImageIcon(titleScreen.getTitleScreen());
    JLabel leaf = new JLabel (leafBk); 
    titlePanel.add(leaf); 

    //aligns buttons 
    instructions.setAlignmentX(CENTER_ALIGNMENT);//**centers the buttons(they would be to the left otherwise) 
    playButton.setAlignmentX(CENTER_ALIGNMENT);
    aboutButton.setAlignmentX(CENTER_ALIGNMENT);
    exitButton.setAlignmentX(CENTER_ALIGNMENT);
    leaf.setAlignmentX(CENTER_ALIGNMENT);
    
    //add action listenors
    instructions.addActionListener(this);
    playButton.addActionListener(this);
    aboutButton.addActionListener(this);
    exitButton.addActionListener(this);  
    nextLevel.addActionListener(this); 
    toMainMenu.addActionListener(this); 
//***************************************************************************************************************************      
    //add components to button panel 
    buttons.add(Box.createVerticalStrut(100));
    buttons.add(instructions); //**adds all buttons to one panel 
    buttons.add(Box.createVerticalStrut(30));//**creates space in between buttons 
    buttons.add(playButton); 
    buttons.add(Box.createVerticalStrut(30));
    buttons.add(aboutButton); 
    buttons.add(Box.createVerticalStrut(30));
    buttons.add(exitButton); 
    buttons.add(Box.createVerticalStrut(30));//**pushes the buttons up from the bottom of the panel 
    buttons.setOpaque(false); 
    
//***************************************************************************************************************************  
    //**pressing instructionsPanel 
    //**creates panels beforehand and sets them to non visible 
    back2Menu.setAlignmentX(CENTER_ALIGNMENT); 
    back2Menu.addActionListener(this);    
    
    ImageIcon instructions =new ImageIcon(instructionsScreen.getInstrutionsScreen());
    JLabel instructionScreen = new JLabel (instructions); 
    
    instructionScreen.setAlignmentY(CENTER_ALIGNMENT); 
    instructionScreen.setAlignmentX(CENTER_ALIGNMENT);
    
    instructionsPanel.add(instructionScreen); 
    instructionsPanel.add(back2Menu);
    instructionsPanel.setVisible(false); //**clicking instructions 
    instructionsPanel.setOpaque(false); 
    
//***************************************************************************************************************************    
    
    //**ABOUT screen panel 
    back2Menu2.setAlignmentX(CENTER_ALIGNMENT); 
    back2Menu2.addActionListener(this);      
    
    ImageIcon about1 =new ImageIcon(aboutScreen.getAboutScreen());
    JLabel about = new JLabel (about1); 
    
    about.setAlignmentY(CENTER_ALIGNMENT); 
    about.setAlignmentX(CENTER_ALIGNMENT);
    
    overview.add(about); 
    overview.add(back2Menu2); 
    overview.setVisible(false); 
    overview.setOpaque(false); 
    
//***************************************************************************************************************************
    //adding all components to final panel
    finalPanel.add(titlePanel); 
    titlePanel.setOpaque(false); 
    finalPanel.add(buttons);//**add panel & box to 'master' panel 
    finalPanel.add(instructionsPanel); 
    finalPanel.add(overview); 
    finalPanel.setOpaque(false); 
    this.add(finalPanel);
    setVisible (true); 
  
  }//**end constructor 
  
//***************************************************************************************************************************

  /* actionPerformed
   * Allows Frame to react to user reations via buttons pressed 
   * @param event the event that the user has take 
   * */
  public void actionPerformed (ActionEvent event){//**an abstract class of ActionListener 
    //saves action in a string variable and compares to if statements 
    String command = event.getActionCommand();
    
    if (command.equals("INSTRUCTIONS")){
      titlePanel.setVisible(false); 
      buttons.setVisible(false); 
      instructionsPanel.setVisible(true);
    }
    
    else if(command.equals("PLAY")){
          new Ball7v2(1);
    }//
    
    else if (command.equals("ABOUT")){
      titlePanel.setVisible(false); 
      buttons.setVisible(false); 
      overview.setVisible(true);
    }
    else if (command.equals("EXIT")){
      System.exit(0);
    }
    else if (command.equals("MENU")){
      instructionsPanel.setVisible(false); 
      overview.setVisible(false); 
      titlePanel.setVisible(true); 
      buttons.setVisible(true); 
    }//**end else if 
  }//**end action performend method 
  
  
  /*Creates the game; main method 
   *@param  args   String argument to execute code  
   */ 
  public static void main (String [] args ){//**short main to create JFrame 
    new FerretMenuXX(); 
  }//**end main 
} //**end class 
//********************************************************************//********************************************************************
