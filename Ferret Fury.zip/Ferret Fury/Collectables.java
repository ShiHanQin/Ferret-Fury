/*Collectables.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for collectable objects
 */

class Collectables extends InanimateObject {
  private int idNumber; //**will be an array of collectables; fill out slots gathered 
  //private boolean collected=false;
  
  /**
   * Collectables
   * This construtor creates a collectable object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   */
  Collectables (int x, int y){
    super (x, y); 
  }//**end constructor 
  
  /**
   * Collectables
   * This construtor creates a collectable object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param int id stores which collectable and keeps track
   */
  Collectables (int x, int y, int id){
    super (x, y); 
    idNumber = id; 
  }//**end constructor 
}//**end class 

