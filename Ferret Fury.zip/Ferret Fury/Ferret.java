/*Ferret.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for the ferret character
 */

class Ferret extends AnimateObject {
  private int health;
  
  /**
   * Ferret
   * This construtor creates a ferret object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param int numCollectables stores # of collectables object has
   */
  Ferret(int x, int y){
   super(x,y);
  }
  
  /**
   * Ferret
   * This construtor creates a ferret object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param int velx stores horizontal speed
   * @param int vely stores vertical speed
   * @param int numCollectables stores # of collectables of object
   * @param int h stores health of character
   */
  Ferret(int x, int y, int velx, int vely, int h){
   super(x,y,velx, vely); 
   this.health=h;
  }

  /////////////////////////////////////////SET METHODS////////////////////////////////// 
  /**
   * setHealth
   * This method updates the health of ferret 
   * @param int h is the new health
   */
  public void setHealth (int h){
    this.health=h;
  }
  
  ///////////////////////////////////////GET METHODS//////////////////////////////////////
  /**
   * getHealth
   * This method returns the health of ferret
   * @return int health is the health of the ferret
   */
  public int getHealth (){
    return health; 
  }//**end get method 
}//**end Ferret subclass 
