/*AnimateObject.java
 * Created by Shi Han Qin and Joanna Tien
 * January 18th, 2018
 * The program contains functions for animate objects like the character and enemies
 */

abstract class AnimateObject { 
  //Position variables for object
  private int x; 
  private int y; 
  //Dimensions of object
  private int height; 
  private int width;
  //Vertical and horizontal speeds of object
  private int velx;
  private int vely;
  
  /**
   * AnimateObject
   * This construtor creates an animate object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   */
  AnimateObject (int x, int y){
    this.x=x;
    this.y=y;
  }
  
  /**
   * AnimateObject
   * This construtor creates an animate object
   * @param int x stores the object's x position
   * @param int y stores the object's y position
   * @param int velx stores horizontal speed
   * @param int vely stores vertical speed
   */
  AnimateObject (int x, int y, int velx, int vely){
    this.x=x;
    this.y=y;
    this.velx=velx;
    this.vely=vely;
  }
  
  ////////////////////////////////GET METHODS//////////////////////////////////////////////////
  /**
   * getX
   * This method returns the x value of the object
   * @return the x value
   */
  public int getX(){
    return x; 
  }//**end get method 
  
  /**
   * getY
   * This method returns the y value of the object
   * @return the y value
   */
  public int getY() {
    return y; 
  }//**end get method 
  
  /**
   * getVelX
   * This method returns the horizontal velocity of the object
   * @return the horizontal velocity value
   */
  public int getVelX(){
    return velx; 
  }//**end get method 
  
  /**
   * getVelY
   * This method returns the vertical velocity of the object
   * @return the vertical velocity value
   */
  public int getVelY() {
    return vely; 
  }//**end get method 
  
  /**
   * getHeight
   * This method returns the height of the object
   * @return the height
   */ 
  public int getHeight(){ 
    return height; 
  }//**end get method 
  
  /**
   * getWidth
   * This method returns the width of the object
   * @return the width
   */ 
  public int getWidth(){ 
    return width; 
  }//**end get method 
  
  /////////////////////////////////////SET METHODS//////////////////////////////////////////////
  /**
   * setVelX
   * This method sets a new horizontal velocity for the object
   * @param int velx the new value of the horizontal velocity
   */ 
  public void setVelX(int velx){
    this.velx=velx; 
  }//**end set method 
  
  /**
   * setVelY
   * This method sets a new vertical velocity for the object
   * @param int vely the new value of the vertical velocity
   */ 
  public void setVelY(int vely) {
    this.vely=vely; 
  }//**end set method 

  /**
   * setX
   * This method sets a new x position for the object
   * @param int x the new value of the x position
   */ 
  public void setX(int x){
    this.x=x;
  }
  
  /**
   * setY
   * This method sets a new y position for the object
   * @param int y the new value of the y position
   */ 
  public void setY(int y){
    this.y=y;
  }

}//**end class 